document.addEventListener("DOMContentLoaded", function () {
    const texto = `Uma mistura de Design, Desenvolvimento Frontend e habilidade\nprofissional que vão destacar seu produto no mercado.`;
    const elemento = document.querySelector(".digitando");

    let index = 0;
    let cursor = document.createElement("span");
    cursor.classList.add("cursor");

    function escreverTexto() {
        if (index < texto.length) {
            if (texto.charAt(index) === "\n") {
                let quebraLinha = document.createElement("br");
                elemento.appendChild(quebraLinha);
            } else {
                let charSpan = document.createElement("span");
                charSpan.textContent = texto.charAt(index);
                elemento.appendChild(charSpan);
                charSpan.appendChild(cursor);   
            }
            elemento.appendChild(cursor); 
            index++;
            setTimeout(escreverTexto, 50);
        }
    }

    elemento.innerHTML = "";
    elemento.appendChild(cursor);
    escreverTexto();
});


const projetos = document.querySelectorAll('.projeto-item');

projetos.forEach((projeto) => {
    projeto.addEventListener('click', () => {
        const link = projeto.getAttribute('data-href'); 
        if (link) {
            window.location.href = link; 
        }
    });
});